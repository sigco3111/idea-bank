# Parcel Tracker Skill

국내외 택배 배송 조회 OpenClaw 스킬입니다.

## 지원 택배사
CJ대한통운, 한진택배, 롯데글로벌로지스, CU편의점택배, 우체국택배, UPS, FedEx, DHL, USPS

## 기능
- 운송장번호로 배송 상태 조회 (택배사 자동 감지)
- 모니터링 등록 및 상태 변경 알림
- 택배사별 상태를 통일 코드로 정규화

## 설치
```
clawhub install parcel-tracker
```

또는 `.skill` 파일을 다운로드하여 OpenClaw skills 폴더에 배치하세요.

## 사용법
- "택배 조회 [운송장번호]"
- "배송 상태 확인해줘"
- 운송장번호만 보내도 자동 감지합니다

## 의존성
- Python 3.8+
- `requests>=2.28.0`
- `beautifulsoup4>=4.11.0`

## 라이선스
MIT
