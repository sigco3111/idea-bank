---
description: Carrier API endpoints and scraping targets for parcel tracking
---

# Carrier API & Tracking Endpoints

## Korean Carriers

### CJ대한통운
- **Method**: Web scraping (POST)
- **URL**: `https://www.cjlogistics.com/ko/tool/parcel/tracking-detail`
- **Params**: `paramInvcNo` (tracking number)
- **Auth**: None (session cookie needed)
- **Rate limit**: Moderate - use session to avoid blocks

### 한진택배
- **Method**: Web scraping (GET)
- **URL**: `https://www.hanjin.com/kor/CMS/DeliveryMgr/WaybillResult.do`
- **Params**: `mession=searchRoutePop`, `wblnumText2` (tracking number)
- **Auth**: None

### 롯데글로벌로지스
- **Method**: Web scraping (POST)
- **URL**: `https://www.lotteglogis.com/home/reservation/tracking/link498`
- **Params**: `InvNo` (tracking number)
- **Auth**: None

### CU편의점택배
- **Method**: Web scraping (POST)
- **URL**: `https://www.cupost.co.kr/postbox/delivery/localResult.cupost`
- **Params**: `invoice_no` (tracking number)
- **Auth**: None

### 우체국택배
- **Method**: Web scraping (GET)
- **URL**: `https://service.epost.go.kr/trace.RetrieveDomRi498.postal`
- **Params**: `sid1` (tracking number)
- **Auth**: None

## International Carriers

### UPS
- **Method**: JSON API (POST)
- **URL**: `https://www.ups.com/track/api/Track/GetStatus`
- **Params**: JSON body `{"Locale": "en_US", "TrackingNumber": ["..."]}`
- **Auth**: None for basic tracking
- **Notes**: Official API (developer.ups.com) requires OAuth2 for production use

### FedEx
- **Method**: Form POST
- **URL**: `https://www.fedex.com/trackingCal/track`
- **Params**: `action=trackpackages`, `data` (JSON string), `locale`
- **Auth**: None for web endpoint
- **Notes**: Official Track API requires API key from developer.fedex.com

### DHL
- **Method**: REST API (GET)
- **URL**: `https://api-eu.dhl.com/track/shipments`
- **Params**: `trackingNumber` query param
- **Auth**: API key recommended (developer.dhl.com)
- **Notes**: Basic tracking may work without key; rate limited

### USPS
- **Method**: Web scraping (GET)
- **URL**: `https://tools.usps.com/go/TrackConfirmAction`
- **Params**: `tLabels` (tracking number)
- **Auth**: None
- **Notes**: Official Web Tools API requires registration at usps.com/business/web-tools-apis

## Alternative: Aggregation APIs

### Tracktry (tracktry.com)
- Supports 1000+ carriers globally
- Free tier: 100 trackings/month
- API: `https://api.tracktry.com/v1/trackings`

### AfterShip (aftership.com)
- Supports 900+ carriers
- Free tier: 50 trackings/month
- API: `https://api.aftership.com/v4/trackings`

These aggregation APIs can be used as fallback when direct carrier scraping fails.
