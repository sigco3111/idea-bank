---
description: Tracking number format patterns by carrier for auto-detection
---

# Tracking Number Patterns

## Korean Carriers

### CJ대한통운
- **Format**: 11 or 13 digits
- **Examples**: `12345678901`, `1234567890123`
- **Notes**: Most common Korean carrier. 11-digit is standard.

### 한진택배
- **Format**: 12 digits
- **Examples**: `123456789012`
- **Notes**: Overlaps with FedEx (12-digit). Context needed for disambiguation.

### 롯데글로벌로지스
- **Format**: 12 digits
- **Examples**: `123456789012`
- **Notes**: Same length as 한진. May need user confirmation when ambiguous.

### CU편의점택배
- **Format**: 10 digits
- **Examples**: `1234567890`
- **Notes**: Overlaps with DHL (10-digit).

### 우체국택배
- **Format**: 13 digits or international format (AA123456789KR)
- **Examples**: `1234567890123`, `EA123456789KR`
- **Notes**: 13-digit overlaps with CJ. International uses letter prefix + KR suffix.

## International Carriers

### UPS
- **Format**: `1Z` + 16 alphanumeric, or `T` + 10 digits
- **Examples**: `1Z999AA10123456784`, `T1234567890`
- **Notes**: 1Z prefix is definitive for UPS.

### FedEx
- **Format**: 12, 15, 20, or 22 digits
- **Examples**: `123456789012`, `123456789012345`
- **Notes**: 12-digit overlaps with Korean carriers. 15+ digits are FedEx-specific.

### DHL
- **Format**: 10 digits, 3 letters + 7 digits, or `JD` + 18 digits
- **Examples**: `1234567890`, `ABC1234567`, `JD012345678901234567`
- **Notes**: 3-letter prefix format is DHL Express specific.

### USPS
- **Format**: 20, 22, or 26 digits; international format (AA123456789AA)
- **Examples**: `12345678901234567890`, `EA123456789US`
- **Notes**: Starts with `94` for many domestic services. International uses country code suffix.

## Disambiguation Rules

When multiple carriers match the same pattern:
1. **12 digits**: Could be 한진, 롯데, or FedEx → check if number starts with Korean carrier prefixes
2. **13 digits**: Could be CJ or 우체국 → try CJ first (more common)
3. **10 digits**: Could be CU or DHL → check if alphanumeric (DHL) or pure numeric (CU)
4. **20+ digits**: USPS or FedEx → check if starts with `94` (USPS)

When ambiguous, query multiple carriers and return the one with valid results.
