#!/usr/bin/env python3
"""
택배 상태 정규화 모듈
Normalize carrier-specific statuses into a unified format.
"""

from __future__ import annotations

# 통합 상태 코드 정의
UNIFIED_STATUSES = {
    "READY":            {"kr": "배송준비",  "en": "Ready"},
    "PICKED_UP":        {"kr": "집하완료",  "en": "Picked up"},
    "IN_TRANSIT":       {"kr": "이동중",    "en": "In transit"},
    "OUT_FOR_DELIVERY": {"kr": "배달출발",  "en": "Out for delivery"},
    "DELIVERED":        {"kr": "배달완료",  "en": "Delivered"},
    "EXCEPTION":        {"kr": "배송이상",  "en": "Exception"},
    "RETURNED":         {"kr": "반송",      "en": "Returned"},
    "UNKNOWN":          {"kr": "알수없음",  "en": "Unknown"},
}

# 각 택배사별 상태 매핑 테이블
# 키워드 기반 매핑 - 상태 문자열에 키워드가 포함되면 해당 통합 상태로 변환
_KEYWORD_MAP: list[tuple[list[str], str]] = [
    # DELIVERED
    (["배달완료", "배달 완료", "인수자", "수령", "delivered", "delivery completed",
      "배달(완료)", "전달완료"], "DELIVERED"),
    # OUT_FOR_DELIVERY
    (["배달출발", "배달 출발", "배송출발", "out for delivery", "배달중",
      "배달예정", "배달차량"], "OUT_FOR_DELIVERY"),
    # PICKED_UP
    (["집하", "접수", "발송", "picked up", "shipment picked up",
      "상품인수", "물품접수"], "PICKED_UP"),
    # IN_TRANSIT
    (["상차", "하차", "간선", "행낭", "도착", "출발", "이동", "경유",
      "in transit", "hub", "center", "facility", "processing",
      "터미널", "분류", "입고", "출고", "운송중", "이관"], "IN_TRANSIT"),
    # EXCEPTION
    (["미배달", "반송요청", "exception", "delay", "지연", "보관",
      "수취인부재", "주소불명", "배송실패", "failed"], "EXCEPTION"),
    # RETURNED
    (["반송", "returned", "return to sender", "환불"], "RETURNED"),
    # READY
    (["접수대기", "정보수신", "ready", "information received",
      "운송장출력", "상품준비"], "READY"),
]

# 택배사별 정확한 상태 매핑 (API 응답값 기준)
CARRIER_STATUS_MAP: dict[str, dict[str, str]] = {
    "cj": {
        "상품인수": "PICKED_UP",
        "간선상차": "IN_TRANSIT",
        "간선하차": "IN_TRANSIT",
        "배달출발": "OUT_FOR_DELIVERY",
        "배달완료": "DELIVERED",
    },
    "hanjin": {
        "접수": "PICKED_UP",
        "집하": "PICKED_UP",
        "이동중": "IN_TRANSIT",
        "배송출발": "OUT_FOR_DELIVERY",
        "배송완료": "DELIVERED",
    },
    "lotte": {
        "집하처리": "PICKED_UP",
        "간선출발": "IN_TRANSIT",
        "간선도착": "IN_TRANSIT",
        "배달출발": "OUT_FOR_DELIVERY",
        "배달완료": "DELIVERED",
    },
    "cu": {
        "택배접수": "PICKED_UP",
        "입고": "IN_TRANSIT",
        "배송중": "IN_TRANSIT",
        "배달완료": "DELIVERED",
    },
    "epost": {
        "접수": "PICKED_UP",
        "발송": "IN_TRANSIT",
        "도착": "IN_TRANSIT",
        "배달준비": "OUT_FOR_DELIVERY",
        "배달완료": "DELIVERED",
    },
    "ups": {
        "Pickup Scan": "PICKED_UP",
        "In Transit": "IN_TRANSIT",
        "Out For Delivery": "OUT_FOR_DELIVERY",
        "Delivered": "DELIVERED",
    },
    "fedex": {
        "Picked up": "PICKED_UP",
        "In transit": "IN_TRANSIT",
        "On FedEx vehicle for delivery": "OUT_FOR_DELIVERY",
        "Delivered": "DELIVERED",
    },
    "dhl": {
        "Shipment picked up": "PICKED_UP",
        "In transit": "IN_TRANSIT",
        "With delivery courier": "OUT_FOR_DELIVERY",
        "Delivered": "DELIVERED",
    },
    "usps": {
        "Accepted": "PICKED_UP",
        "In Transit to Next Facility": "IN_TRANSIT",
        "Out for Delivery": "OUT_FOR_DELIVERY",
        "Delivered": "DELIVERED",
    },
}


def normalize(raw_status: str, carrier: str | None = None) -> str:
    """
    택배사 상태를 통합 상태 코드로 변환한다.

    Args:
        raw_status: 택배사 원본 상태 문자열
        carrier: 택배사 코드 (선택). 제공 시 정확한 매핑 우선 적용.

    Returns:
        통합 상태 코드 문자열 (예: "IN_TRANSIT")
    """
    if not raw_status:
        return "UNKNOWN"

    cleaned = raw_status.strip()

    # 1단계: 택배사 코드가 있으면 정확한 매핑 먼저 시도
    if carrier and carrier in CARRIER_STATUS_MAP:
        exact = CARRIER_STATUS_MAP[carrier].get(cleaned)
        if exact:
            return exact

    # 2단계: 키워드 기반 매핑
    lower = cleaned.lower()
    for keywords, status in _KEYWORD_MAP:
        for kw in keywords:
            if kw.lower() in lower:
                return status

    return "UNKNOWN"


def get_status_label(code: str, lang: str = "kr") -> str:
    """통합 상태 코드의 한글/영문 라벨 반환"""
    info = UNIFIED_STATUSES.get(code, UNIFIED_STATUSES["UNKNOWN"])
    return info.get(lang, info["kr"])


def is_terminal(code: str) -> bool:
    """배송 완료/반송 등 최종 상태인지 확인"""
    return code in ("DELIVERED", "RETURNED")


def is_alertable(code: str) -> bool:
    """알림을 보내야 하는 상태인지 확인"""
    return code in ("DELIVERED", "OUT_FOR_DELIVERY", "EXCEPTION", "RETURNED")


if __name__ == "__main__":
    # 테스트
    tests = [
        ("간선상차", "cj", "IN_TRANSIT"),
        ("배달완료", None, "DELIVERED"),
        ("Out for Delivery", "usps", "OUT_FOR_DELIVERY"),
        ("Delivered", "fedex", "DELIVERED"),
        ("수취인부재", None, "EXCEPTION"),
        ("", None, "UNKNOWN"),
    ]
    for raw, carrier, expected in tests:
        result = normalize(raw, carrier)
        mark = "OK" if result == expected else "FAIL"
        print(f"[{mark}] normalize({raw!r}, {carrier!r}) = {result} (expected {expected})")
