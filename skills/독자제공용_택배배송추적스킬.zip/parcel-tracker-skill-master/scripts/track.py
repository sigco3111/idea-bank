#!/usr/bin/env python3
"""
택배 조회 메인 스크립트
Main parcel tracking script - queries carrier APIs/pages and returns unified status JSON.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone, timedelta
from typing import Any

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    print(json.dumps({
        "error": "Missing dependencies. Install with: pip install requests beautifulsoup4"
    }))
    sys.exit(1)

from detect_carrier import detect_best
from normalize_status import normalize, get_status_label, UNIFIED_STATUSES

KST = timezone(timedelta(hours=9))

# ──────────────────────────────────────────────
# 택배사별 조회 함수
# ──────────────────────────────────────────────

def _make_result(
    tracking_number: str,
    carrier: str,
    carrier_name: str,
    events: list[dict],
) -> dict:
    """통합 결과 JSON 구조 생성"""
    latest_status = events[0]["status"] if events else "UNKNOWN"
    return {
        "tracking_number": tracking_number,
        "carrier": carrier,
        "carrier_name": carrier_name,
        "status": latest_status,
        "status_kr": get_status_label(latest_status, "kr"),
        "status_en": get_status_label(latest_status, "en"),
        "last_update": events[0]["time"] if events else None,
        "event_count": len(events),
        "events": events,
        "queried_at": datetime.now(KST).isoformat(),
    }


def _parse_event(
    time_str: str,
    location: str,
    description: str,
    carrier: str,
) -> dict:
    """개별 이벤트 파싱 및 상태 정규화"""
    return {
        "time": time_str,
        "location": location.strip() if location else "",
        "description": description.strip() if description else "",
        "status": normalize(description, carrier),
    }


# ──────────────────────────────────────────────
# tracker.delivery API (한국 택배 통합 조회)
# ──────────────────────────────────────────────

# 택배사 코드 → tracker.delivery carrier ID 매핑
_TRACKER_DELIVERY_MAP = {
    "cj": "kr.cjlogistics",
    "hanjin": "kr.hanjin",
    "lotte": "kr.lotte",
    "cu": "kr.cupost",
    "epost": "kr.epost",
}

# tracker.delivery 상태 ID → 통합 상태 코드 매핑
_TRACKER_STATUS_MAP = {
    "information_received": "READY",
    "at_pickup": "PICKED_UP",
    "in_transit": "IN_TRANSIT",
    "out_for_delivery": "OUT_FOR_DELIVERY",
    "delivered": "DELIVERED",
    "exception": "EXCEPTION",
}

# 택배사 코드 → 한글 이름
_CARRIER_NAMES = {
    "cj": "CJ대한통운",
    "hanjin": "한진택배",
    "lotte": "롯데글로벌로지스",
    "cu": "CU편의점택배",
    "epost": "우체국택배",
}


def _track_via_tracker_delivery(tracking_number: str, carrier: str) -> dict:
    """tracker.delivery API를 이용한 한국 택배 조회"""
    carrier_id = _TRACKER_DELIVERY_MAP.get(carrier)
    if not carrier_id:
        return {"error": f"tracker.delivery에서 지원하지 않는 택배사: {carrier}"}

    carrier_name = _CARRIER_NAMES.get(carrier, carrier)
    url = f"https://apis.tracker.delivery/carriers/{carrier_id}/tracks/{tracking_number}"

    try:
        resp = requests.get(url, timeout=15, headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        })
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as e:
        return {"error": f"{carrier_name} 조회 실패: {e}", "carrier": carrier}
    except json.JSONDecodeError:
        return {"error": f"{carrier_name} 조회 응답 파싱 실패", "carrier": carrier}

    events = []
    for prog in data.get("progresses", []):
        status_id = prog.get("status", {}).get("id", "")
        unified = _TRACKER_STATUS_MAP.get(status_id, "UNKNOWN")
        status_text = prog.get("status", {}).get("text", "")
        description = prog.get("description", status_text)

        events.append({
            "time": prog.get("time", ""),
            "location": prog.get("location", {}).get("name", ""),
            "description": description,
            "status": unified,
        })

    # 최신 이벤트가 맨 위로
    events.reverse()
    return _make_result(tracking_number, carrier, carrier_name, events)


# ── 한국 택배사 공통 (tracker.delivery 사용) ──
def track_cj(tracking_number: str) -> dict:
    """CJ대한통운 조회"""
    return _track_via_tracker_delivery(tracking_number, "cj")

def track_hanjin(tracking_number: str) -> dict:
    """한진택배 조회"""
    return _track_via_tracker_delivery(tracking_number, "hanjin")

def track_lotte(tracking_number: str) -> dict:
    """롯데글로벌로지스 조회"""
    return _track_via_tracker_delivery(tracking_number, "lotte")

def track_cu(tracking_number: str) -> dict:
    """CU편의점택배 조회"""
    return _track_via_tracker_delivery(tracking_number, "cu")

def track_epost(tracking_number: str) -> dict:
    """우체국택배 조회"""
    return _track_via_tracker_delivery(tracking_number, "epost")


# ── UPS ──
def track_ups(tracking_number: str) -> dict:
    """UPS 조회 (공개 JSON endpoint)"""
    url = "https://www.ups.com/track/api/Track/GetStatus"
    headers = {"Content-Type": "application/json"}
    payload = {"Locale": "en_US", "TrackingNumber": [tracking_number]}
    try:
        resp = requests.post(url, json=payload, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except (requests.RequestException, json.JSONDecodeError) as e:
        return {"error": f"UPS 조회 실패: {e}", "carrier": "ups"}

    events = []
    try:
        shipment = data.get("trackDetails", [{}])[0]
        activities = shipment.get("shipmentProgressActivities", [])
        for act in activities:
            events.append(_parse_event(
                time_str=f"{act.get('date', '')} {act.get('time', '')}".strip(),
                location=act.get("location", ""),
                description=act.get("activityScan", ""),
                carrier="ups",
            ))
    except (KeyError, IndexError):
        pass

    return _make_result(tracking_number, "ups", "UPS", events)


# ── FedEx ──
def track_fedex(tracking_number: str) -> dict:
    """FedEx 조회"""
    url = "https://www.fedex.com/trackingCal/track"
    data_param = json.dumps({
        "TrackPackagesRequest": {
            "appType": "WTRK",
            "uniqueKey": "",
            "processingParameters": {},
            "trackingInfoList": [{"trackNumberInfo": {"trackingNumber": tracking_number}}],
        }
    })
    try:
        resp = requests.post(url, data={
            "data": data_param,
            "action": "trackpackages",
            "locale": "en_US",
        }, timeout=15)
        resp.raise_for_status()
        result = resp.json()
    except (requests.RequestException, json.JSONDecodeError) as e:
        return {"error": f"FedEx 조회 실패: {e}", "carrier": "fedex"}

    events = []
    try:
        pkg = result["TrackPackagesResponse"]["packageList"][0]
        for scan in pkg.get("scanEventList", []):
            events.append(_parse_event(
                time_str=f"{scan.get('date', '')} {scan.get('time', '')}".strip(),
                location=scan.get("scanLocation", ""),
                description=scan.get("status", ""),
                carrier="fedex",
            ))
    except (KeyError, IndexError):
        pass

    return _make_result(tracking_number, "fedex", "FedEx", events)


# ── DHL ──
def track_dhl(tracking_number: str) -> dict:
    """DHL 조회 (공개 endpoint)"""
    url = f"https://api-eu.dhl.com/track/shipments?trackingNumber={tracking_number}"
    headers = {"Accept": "application/json"}
    try:
        resp = requests.get(url, headers=headers, timeout=15)
        resp.raise_for_status()
        data = resp.json()
    except (requests.RequestException, json.JSONDecodeError) as e:
        return {"error": f"DHL 조회 실패: {e}", "carrier": "dhl"}

    events = []
    try:
        shipments = data.get("shipments", [])
        if shipments:
            for event in shipments[0].get("events", []):
                loc_data = event.get("location", {}).get("address", {})
                location = loc_data.get("addressLocality", "")
                events.append(_parse_event(
                    time_str=event.get("timestamp", ""),
                    location=location,
                    description=event.get("description", ""),
                    carrier="dhl",
                ))
    except (KeyError, IndexError):
        pass

    return _make_result(tracking_number, "dhl", "DHL", events)


# ── USPS ──
def track_usps(tracking_number: str) -> dict:
    """USPS 조회 (스크래핑)"""
    url = f"https://tools.usps.com/go/TrackConfirmAction?tRef=fullpage&tLc=2&text28777=&tLabels={tracking_number}"
    try:
        resp = requests.get(url, timeout=15)
        resp.raise_for_status()
    except requests.RequestException as e:
        return {"error": f"USPS 조회 실패: {e}", "carrier": "usps"}

    soup = BeautifulSoup(resp.text, "html.parser")
    events = []

    # USPS 배송 이력 파싱
    containers = soup.select(".tb-step")
    for container in containers:
        date_el = container.select_one(".tb-date")
        status_el = container.select_one(".tb-status-detail")
        loc_el = container.select_one(".tb-location")
        if status_el:
            events.append(_parse_event(
                time_str=date_el.get_text(strip=True) if date_el else "",
                location=loc_el.get_text(strip=True) if loc_el else "",
                description=status_el.get_text(strip=True),
                carrier="usps",
            ))

    return _make_result(tracking_number, "usps", "USPS", events)


# ──────────────────────────────────────────────
# 택배사 라우터
# ──────────────────────────────────────────────

TRACKER_MAP = {
    "cj": track_cj,
    "hanjin": track_hanjin,
    "lotte": track_lotte,
    "cu": track_cu,
    "epost": track_epost,
    "ups": track_ups,
    "fedex": track_fedex,
    "dhl": track_dhl,
    "usps": track_usps,
}


def track(tracking_number: str, carrier: str | None = None) -> dict:
    """
    택배 조회 메인 함수

    Args:
        tracking_number: 운송장 번호
        carrier: 택배사 코드 (None이면 자동 감지)

    Returns:
        통합 형식의 조회 결과 JSON dict
    """
    # 택배사 자동 감지
    if not carrier:
        detected = detect_best(tracking_number)
        if not detected:
            return {
                "error": f"택배사를 자동 감지할 수 없습니다. --carrier 옵션을 사용해 주세요.",
                "tracking_number": tracking_number,
            }
        carrier = detected["carrier"]

    tracker_fn = TRACKER_MAP.get(carrier)
    if not tracker_fn:
        return {
            "error": f"지원하지 않는 택배사입니다: {carrier}",
            "supported": list(TRACKER_MAP.keys()),
        }

    return tracker_fn(tracking_number)


def main():
    parser = argparse.ArgumentParser(description="택배 조회 (Parcel Tracker)")
    parser.add_argument("tracking_number", help="운송장 번호")
    parser.add_argument("--carrier", "-c", help="택배사 코드 (cj, hanjin, lotte, cu, epost, ups, fedex, dhl, usps)")
    parser.add_argument("--pretty", "-p", action="store_true", help="Pretty-print JSON output")
    args = parser.parse_args()

    result = track(args.tracking_number, args.carrier)
    indent = 2 if args.pretty else None
    print(json.dumps(result, ensure_ascii=False, indent=indent))


if __name__ == "__main__":
    main()
