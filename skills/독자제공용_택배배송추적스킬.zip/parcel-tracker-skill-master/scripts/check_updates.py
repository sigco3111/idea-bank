#!/usr/bin/env python3
"""
택배 상태 변경 확인 스크립트
Check all registered parcels for status changes and output alerts.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone, timedelta

from register_parcel import list_parcels, update_status, deactivate
from track import track
from normalize_status import is_terminal, is_alertable, get_status_label

KST = timezone(timedelta(hours=9))


def check_all(notify: bool = False) -> dict:
    """
    등록된 모든 활성 택배의 상태를 확인하고 변경사항을 반환한다.

    Args:
        notify: True이면 알림이 필요한 변경사항만 포함

    Returns:
        {
            "checked_at": "...",
            "total": 3,
            "changed": [...],
            "unchanged": [...],
            "errors": [...]
        }
    """
    parcels = list_parcels(active_only=True)
    now = datetime.now(KST).isoformat()

    result = {
        "checked_at": now,
        "total": len(parcels),
        "changed": [],
        "unchanged": [],
        "errors": [],
    }

    if not parcels:
        result["message"] = "등록된 활성 택배가 없습니다."
        return result

    for parcel in parcels:
        tn = parcel["tracking_number"]
        carrier = parcel["carrier"]
        prev_status = parcel.get("last_status")

        # 조회
        tracking_result = track(tn, carrier)

        if "error" in tracking_result:
            result["errors"].append({
                "tracking_number": tn,
                "carrier": carrier,
                "label": parcel.get("label", ""),
                "error": tracking_result["error"],
            })
            continue

        current_status = tracking_result.get("status", "UNKNOWN")

        # 상태 업데이트 저장
        update_status(tn, current_status, now)

        # 변경 여부 판단
        changed = prev_status is not None and prev_status != current_status

        entry = {
            "tracking_number": tn,
            "carrier": carrier,
            "carrier_name": tracking_result.get("carrier_name", ""),
            "label": parcel.get("label", ""),
            "previous_status": prev_status,
            "current_status": current_status,
            "current_status_kr": get_status_label(current_status, "kr"),
            "last_event": tracking_result["events"][0] if tracking_result.get("events") else None,
        }

        if changed:
            entry["alert"] = is_alertable(current_status)
            result["changed"].append(entry)

            # 최종 상태 도달 시 비활성화
            if is_terminal(current_status):
                deactivate(tn)
                entry["deactivated"] = True
        else:
            if not notify:  # --notify 모드에서는 변경 없는 건 생략
                result["unchanged"].append(entry)

    # 요약
    result["summary"] = {
        "changed_count": len(result["changed"]),
        "unchanged_count": len(result["unchanged"]),
        "error_count": len(result["errors"]),
        "alerts": [
            c for c in result["changed"] if c.get("alert")
        ],
    }

    return result


def format_alert_message(alerts: list[dict]) -> str:
    """알림 메시지를 사람이 읽기 좋은 형태로 포맷"""
    if not alerts:
        return "상태 변경 알림 없음"

    lines = ["📦 택배 상태 변경 알림", "=" * 30]
    for a in alerts:
        label = a.get("label") or a["tracking_number"]
        prev = get_status_label(a["previous_status"], "kr") if a["previous_status"] else "없음"
        curr = a["current_status_kr"]
        carrier = a.get("carrier_name", a["carrier"])

        lines.append(f"")
        lines.append(f"[{carrier}] {label}")
        lines.append(f"  운송장: {a['tracking_number']}")
        lines.append(f"  상태: {prev} → {curr}")

        event = a.get("last_event")
        if event:
            lines.append(f"  위치: {event.get('location', '-')}")
            lines.append(f"  시간: {event.get('time', '-')}")

        if a.get("deactivated"):
            lines.append(f"  ✅ 모니터링 자동 종료")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="등록된 택배 상태 변경 확인")
    parser.add_argument("--notify", "-n", action="store_true",
                        help="알림이 필요한 변경사항만 출력")
    parser.add_argument("--pretty", "-p", action="store_true",
                        help="Pretty-print JSON")
    parser.add_argument("--human", action="store_true",
                        help="사람이 읽기 좋은 형태로 출력")
    args = parser.parse_args()

    result = check_all(notify=args.notify)

    if args.human:
        alerts = result.get("summary", {}).get("alerts", [])
        if alerts:
            print(format_alert_message(alerts))
        elif result.get("changed"):
            print(format_alert_message(result["changed"]))
        else:
            print("📦 상태 변경 없음")
            print(f"  확인: {result['total']}건, 오류: {len(result.get('errors', []))}건")
    else:
        indent = 2 if args.pretty else None
        print(json.dumps(result, ensure_ascii=False, indent=indent))


if __name__ == "__main__":
    main()
