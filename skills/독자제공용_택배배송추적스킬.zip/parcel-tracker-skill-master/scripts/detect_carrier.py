#!/usr/bin/env python3
"""
운송장 번호로 택배사 자동 감지
Auto-detect carrier from tracking number format/pattern.
"""

from __future__ import annotations

import re
import json
import sys
from pathlib import Path

# 택배사별 운송장 번호 패턴
# 한국 택배사를 우선 배치 (국내 사용이 많으므로)
# 구체적인 패턴(영문 prefix 등)이 있는 국제 택배사는 맨 앞에 배치
CARRIER_PATTERNS: list[dict] = [
    # ── 고유한 패턴의 국제 택배사 (먼저 매칭) ──
    {
        "carrier": "ups",
        "name": "UPS",
        "patterns": [
            r"^1Z[A-Z0-9]{16}$",        # 1Z + 16자리 영숫자
            r"^T\d{10}$",                # T + 10자리 숫자
        ],
    },
    {
        "carrier": "usps",
        "name": "USPS",
        "patterns": [
            r"^[A-Z]{2}\d{9}[A-Z]{2}$", # 국제우편 (EX: EA123456789KR)
            r"^94\d{18,22}$",            # 94로 시작
            r"^\d{26}$",                 # 26자리 숫자
        ],
    },
    {
        "carrier": "dhl",
        "name": "DHL",
        "patterns": [
            r"^[A-Z]{3}\d{7}$",          # 3글자 + 7숫자 (DHL Express)
            r"^JD\d{18}$",              # JD + 18자리 (eCommerce)
        ],
    },
    # ── 한국 택배사 (숫자만으로 구성, 우선 매칭) ──
    {
        "carrier": "cj",
        "name": "CJ대한통운",
        "patterns": [
            r"^\d{10,13}$",              # 10~13자리 숫자 (가장 일반적 국내 택배)
        ],
    },
    {
        "carrier": "hanjin",
        "name": "한진택배",
        "patterns": [
            r"^\d{10,12}$",              # 10~12자리 숫자
        ],
    },
    {
        "carrier": "lotte",
        "name": "롯데글로벌로지스",
        "patterns": [
            r"^\d{10,12}$",              # 10~12자리 숫자
        ],
    },
    {
        "carrier": "epost",
        "name": "우체국택배",
        "patterns": [
            r"^\d{13}$",                 # 13자리 숫자
            r"^[A-Z]{2}\d{9}KR$",       # 국제등기 (한국 발송)
        ],
    },
    {
        "carrier": "cu",
        "name": "CU편의점택배",
        "patterns": [
            r"^\d{10,12}$",              # 10~12자리 숫자
        ],
    },
    # ── 숫자만 사용하는 국제 택배사 (한국 택배사 이후 매칭) ──
    {
        "carrier": "fedex",
        "name": "FedEx",
        "patterns": [
            r"^\d{12}$",                 # 12자리 숫자
            r"^\d{15}$",                 # 15자리 숫자
            r"^\d{20}$",                 # 20자리 숫자 (Door Tag)
            r"^\d{22}$",                 # 22자리 숫자
        ],
    },
]


def detect_carrier(tracking_number: str) -> list[dict]:
    """
    운송장 번호 패턴으로 가능한 택배사 목록을 반환한다.

    Args:
        tracking_number: 운송장 번호 (공백/하이픈 자동 제거)

    Returns:
        매칭된 택배사 목록 [{"carrier": "cj", "name": "CJ대한통운", "confidence": "high"}, ...]
        여러 택배사가 동일 패턴을 사용하면 모두 반환.
    """
    # 공백, 하이픈, 점 제거
    cleaned = re.sub(r"[\s\-.]", "", tracking_number.strip().upper())

    if not cleaned:
        return []

    matches = []
    for entry in CARRIER_PATTERNS:
        for pattern in entry["patterns"]:
            if re.match(pattern, cleaned):
                matches.append({
                    "carrier": entry["carrier"],
                    "name": entry["name"],
                    "confidence": "high" if len(matches) == 0 else "medium",
                })
                break  # 같은 택배사 내 중복 방지

    return matches


def detect_best(tracking_number: str) -> dict | None:
    """가장 가능성 높은 택배사 하나만 반환"""
    candidates = detect_carrier(tracking_number)
    return candidates[0] if candidates else None


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 detect_carrier.py <tracking_number>")
        sys.exit(1)

    number = sys.argv[1]
    results = detect_carrier(number)

    if results:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"error": f"택배사를 자동 감지할 수 없습니다: {number}"}, ensure_ascii=False))
        sys.exit(1)
