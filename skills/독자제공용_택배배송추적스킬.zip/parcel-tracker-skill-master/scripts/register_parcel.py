#!/usr/bin/env python3
"""
택배 등록/관리 스크립트
Register parcels for periodic monitoring. Stores data in config/parcels.json.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

from detect_carrier import detect_best

KST = timezone(timedelta(hours=9))
CONFIG_DIR = Path(__file__).parent.parent / "config"
PARCELS_FILE = CONFIG_DIR / "parcels.json"


def _load_parcels() -> list[dict]:
    """등록된 택배 목록 로드"""
    if PARCELS_FILE.exists():
        with open(PARCELS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def _save_parcels(parcels: list[dict]) -> None:
    """택배 목록 저장"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(PARCELS_FILE, "w", encoding="utf-8") as f:
        json.dump(parcels, f, ensure_ascii=False, indent=2)


def register(
    tracking_number: str,
    carrier: str | None = None,
    label: str = "",
) -> dict:
    """
    택배를 모니터링 목록에 등록

    Args:
        tracking_number: 운송장 번호
        carrier: 택배사 코드 (None이면 자동 감지)
        label: 사용자 라벨 (예: "엄마가 보낸 택배")

    Returns:
        등록 결과 dict
    """
    parcels = _load_parcels()

    # 중복 검사
    for p in parcels:
        if p["tracking_number"] == tracking_number:
            return {
                "action": "already_exists",
                "message": f"이미 등록된 운송장입니다: {tracking_number}",
                "parcel": p,
            }

    # 택배사 감지
    if not carrier:
        detected = detect_best(tracking_number)
        if detected:
            carrier = detected["carrier"]
        else:
            return {
                "action": "error",
                "message": "택배사를 자동 감지할 수 없습니다. --carrier 옵션을 사용해 주세요.",
            }

    entry = {
        "tracking_number": tracking_number,
        "carrier": carrier,
        "label": label,
        "registered_at": datetime.now(KST).isoformat(),
        "last_status": None,
        "last_checked": None,
        "active": True,
    }

    parcels.append(entry)
    _save_parcels(parcels)

    return {
        "action": "registered",
        "message": f"등록 완료: {tracking_number} ({carrier})",
        "parcel": entry,
    }


def unregister(tracking_number: str) -> dict:
    """택배를 모니터링 목록에서 제거"""
    parcels = _load_parcels()
    original_count = len(parcels)
    parcels = [p for p in parcels if p["tracking_number"] != tracking_number]

    if len(parcels) == original_count:
        return {"action": "not_found", "message": f"등록되지 않은 운송장: {tracking_number}"}

    _save_parcels(parcels)
    return {"action": "unregistered", "message": f"등록 해제: {tracking_number}"}


def list_parcels(active_only: bool = True) -> list[dict]:
    """등록된 택배 목록 반환"""
    parcels = _load_parcels()
    if active_only:
        return [p for p in parcels if p.get("active", True)]
    return parcels


def deactivate(tracking_number: str) -> dict:
    """배달 완료 등으로 모니터링 비활성화"""
    parcels = _load_parcels()
    for p in parcels:
        if p["tracking_number"] == tracking_number:
            p["active"] = False
            _save_parcels(parcels)
            return {"action": "deactivated", "message": f"비활성화: {tracking_number}"}
    return {"action": "not_found", "message": f"등록되지 않은 운송장: {tracking_number}"}


def update_status(tracking_number: str, status: str, checked_at: str) -> None:
    """마지막 조회 상태 업데이트 (check_updates에서 호출)"""
    parcels = _load_parcels()
    for p in parcels:
        if p["tracking_number"] == tracking_number:
            p["last_status"] = status
            p["last_checked"] = checked_at
            break
    _save_parcels(parcels)


def main():
    parser = argparse.ArgumentParser(description="택배 등록 관리")
    sub = parser.add_subparsers(dest="command")

    # register
    reg = sub.add_parser("add", help="택배 등록")
    reg.add_argument("tracking_number", help="운송장 번호")
    reg.add_argument("--carrier", "-c", help="택배사 코드")
    reg.add_argument("--label", "-l", default="", help="라벨/메모")

    # unregister
    unreg = sub.add_parser("remove", help="택배 등록 해제")
    unreg.add_argument("tracking_number", help="운송장 번호")

    # list
    sub.add_parser("list", help="등록된 택배 목록")

    args = parser.parse_args()

    if args.command == "add":
        result = register(args.tracking_number, args.carrier, args.label)
    elif args.command == "remove":
        result = unregister(args.tracking_number)
    elif args.command == "list":
        result = list_parcels()
    else:
        parser.print_help()
        sys.exit(1)

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
