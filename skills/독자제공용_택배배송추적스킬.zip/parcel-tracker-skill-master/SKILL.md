---
name: parcel-tracker
description: Track Korean and international parcels with status alerts. Supports CJ대한통운, 한진, 롯데, CU편의점, 우체국, UPS, FedEx, DHL, USPS. Use when user asks to track a parcel, check delivery status, or mentions 택배, 배송, 운송장, parcel, tracking, 배달, courier, shipment.
---

# Parcel Tracker Skill

Korean and international parcel tracking with unified status normalization and change alerts.

## Supported Couriers

| Courier | Code | Country |
|---------|------|---------|
| CJ대한통운 | `cj` | KR |
| 한진택배 | `hanjin` | KR |
| 롯데글로벌로지스 | `lotte` | KR |
| CU편의점택배 | `cu` | KR |
| 우체국택배 | `epost` | KR |
| UPS | `ups` | US |
| FedEx | `fedex` | US |
| DHL | `dhl` | INT |
| USPS | `usps` | US |

## Usage

### Track a parcel
```bash
python3 scripts/track.py <tracking_number> [--carrier <code>]
```
If `--carrier` is omitted, auto-detection runs via `detect_carrier.py`.

### Register for monitoring
```bash
python3 scripts/register_parcel.py <tracking_number> [--carrier <code>] [--label "my package"]
```
Saves to `config/parcels.json` for periodic checking.

### Check for updates
```bash
python3 scripts/check_updates.py
```
Compares current status against last known state for all registered parcels. Outputs change alerts as JSON.

## Unified Status Codes

All carrier-specific statuses are normalized to:

| Code | Korean | English | Description |
|------|--------|---------|-------------|
| `READY` | 배송준비 | Ready | Shipment info received |
| `PICKED_UP` | 집하완료 | Picked up | Collected from sender |
| `IN_TRANSIT` | 이동중 | In transit | Moving through network |
| `OUT_FOR_DELIVERY` | 배달출발 | Out for delivery | On delivery vehicle |
| `DELIVERED` | 배달완료 | Delivered | Successfully delivered |
| `EXCEPTION` | 배송이상 | Exception | Problem with delivery |
| `RETURNED` | 반송 | Returned | Returned to sender |
| `UNKNOWN` | 알수없음 | Unknown | Cannot determine status |

## Output Format

```json
{
  "tracking_number": "1234567890",
  "carrier": "cj",
  "carrier_name": "CJ대한통운",
  "status": "IN_TRANSIT",
  "status_kr": "이동중",
  "last_update": "2026-03-26T14:30:00+09:00",
  "events": [
    {
      "time": "2026-03-26T14:30:00+09:00",
      "location": "서울 강남 HUB",
      "description": "간선상차",
      "status": "IN_TRANSIT"
    }
  ]
}
```

## Cron Integration

Register a cron job to check active parcels periodically:
```bash
# Check every 2 hours during business hours
0 8-20/2 * * * python3 /path/to/scripts/check_updates.py --notify
```

## Agent Instructions

When the user asks to track a parcel:
1. Extract the tracking number from the message
2. Run `track.py` with the number
3. Present the status in a readable format with Korean labels
4. Offer to register for monitoring if not already registered

When the user asks about registered parcels:
1. Run `check_updates.py` to get current statuses
2. Highlight any status changes since last check
3. Flag exceptions or deliveries prominently

## Dependencies

```
requests>=2.28.0
beautifulsoup4>=4.11.0
```
