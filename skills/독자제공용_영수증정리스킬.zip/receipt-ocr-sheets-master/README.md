# Receipt OCR & Sheets Export 🧾

한국어 영수증 사진을 OCR로 스캔하여 구조화된 데이터로 변환하고 CSV/Google Sheets로 내보내는 스킬입니다.

OpenClaw 에이전트 스킬로 설계되었으며, 독립 CLI 도구로도 사용 가능합니다.

## ✨ Features

- 🇰🇷 **한국어 최적화** — EasyOCR + 오토리서치 최적 파라미터 (`canvas_size=1024`, 27% 빠름)
- 📄 **다중 엔진** — EasyOCR(기본), PaddleOCR, Tesseract 지원
- 📊 **구조화 파싱** — 상호명, 날짜, 품목, 금액, 결제수단 자동 추출
- 📁 **PDF 지원** — opendataloader-pdf 통합
- 📈 **스프레드시트** — CSV / Google Sheets 내보내기
- 🔄 **배치 처리** — 여러 영수증 일괄 처리

## 🚀 설치

```bash
git clone https://github.com/jkf87/receipt-ocr-sheets.git
cd receipt-ocr-sheets

# 가상환경 생성 (권장)
python3 -m venv .venv
source .venv/bin/activate

# 기본 OCR 엔진 설치
pip install -r requirements.txt
```

### 추가 엔진 (옵션)

```bash
# PaddleOCR (정확도 우선, Python 3.11 필요)
pip install paddlepaddle paddleocr

# Tesseract (폴백)
brew install tesseract tesseract-lang
pip install pytesseract

# Google Sheets 연동
pip install gspread google-auth

# PDF 영수증
brew install openjdk@21
pip install opendataloader-pdf
```

## 📖 사용법

### 이미지 OCR

```bash
# 기본 (EasyOCR)
python3 scripts/ocr_extract.py receipt.jpg

# 특정 엔진
python3 scripts/ocr_extract.py receipt.jpg --engine paddleocr

# JSON만 출력
python3 scripts/ocr_extract.py receipt.jpg --json-only
```

### 구조화 파싱

```bash
python3 scripts/parse_receipt.py ocr_result.json
```

### 배치 처리

```bash
python3 scripts/batch_process.py ./receipts/ --output results.csv
```

### CSV 내보내기

```bash
python3 scripts/export_csv.py ocr_result.json --output receipt.csv
```

### Google Sheets 내보내기

```bash
python3 scripts/export_gsheet.py ocr_result.json \
  --spreadsheet "영수증 정리" \
  --credentials service_account.json
```

## ⚡ 성능

Apple Silicon M4 기준:

| 엔진 | 속도 | 한국어 품목 정확도 |
|------|------|-------------------|
| **EasyOCR** (기본) | **~1.7s** | 2/4 |
| PaddleOCR v3 | ~13s | 2/4 |
| Surya OCR | ~29s | 4/4 |

## 📂 프로젝트 구조

```
receipt-ocr-sheets/
├── SKILL.md                    # OpenClaw 스킬 메타데이터
├── README.md                   # 이 파일
├── requirements.txt            # 기본 의존성
├── scripts/
│   ├── ocr_extract.py          # 메인 OCR 추출
│   ├── parse_receipt.py        # 텍스트 구조화 파서
│   ├── export_csv.py           # CSV 내보내기
│   ├── export_gsheet.py        # Google Sheets 내보내기
│   ├── batch_process.py        # 배치 처리
│   ├── extract_pdf.py          # PDF 영수증 추출
│   └── setup_ocr.py            # OCR 엔진 설치 도구
└── references/
    ├── ocr_setup_guide.md      # OCR 엔진 설치 가이드
    ├── receipt_field_mapping.md # 영수증 필드 매핑
    ├── gsheet_oauth_setup.md   # Google Sheets 설정
    └── opendataloader_pdf_setup.md
```

## 📋 지원 형식

- **이미지**: JPG, PNG, BMP, TIFF, WebP
- **PDF**: 텍스트/표 포함 PDF (opendataloader-pdf 필요)

## 🤝 기여

PR 환영합니다! 이슈나 개선사항이 있으면 이슈를 열어주세요.

## 📄 라이선스

MIT
