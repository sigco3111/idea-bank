---
name: receipt-ocr-sheets
description: 영수증 사진을 OCR로 스캔하여 구조화된 데이터로 변환하고 스프레드시트(CSV/Google Sheets)로 내보내기. 한국어 영수증 최적화 (EasyOCR canvas_size=1024).
version: 1.1.0
triggers:
  - 영수증
  - receipt
  - OCR
  - 스프레드시트
  - 영수증 정리
  - receipt scan
  - 영수증 스캔
  - 영수증 OCR
---

# Receipt OCR & Sheets Export

한국어 영수증 사진에서 텍스트를 추출하고, 구조화된 데이터로 파싱한 후 CSV 또는 Google Sheets로 내보내는 스킬입니다.

## Quick Start

```bash
# 1. 이미지 영수증 OCR (기본: EasyOCR)
python3 scripts/ocr_extract.py /path/to/receipt.jpg

# 2. 특정 엔진 지정
python3 scripts/ocr_extract.py /path/to/receipt.jpg --engine paddleocr
python3 scripts/ocr_extract.py /path/to/receipt.jpg --engine tesseract

# 3. PDF 영수증 (opendataloader-pdf)
python3 scripts/extract_pdf.py /path/to/receipt.pdf

# 4. 배치 처리
python3 scripts/batch_process.py /path/to/receipts_dir/ --output results.csv
```

## OCR Engine Selection

### EasyOCR (기본, 권장)
- **속도**: ~1.7s/image (Apple Silicon M4)
- **한국어**: 우수, canvas_size=1024 최적화 적용
- **설치**: `pip install easyocr`
- **장점**: 가장 빠르고 한국어 인식 안정적
- **한계**: 조밀한 표에서 일부 품목명 분할/오인식 가능

### PaddleOCR v3 (정확도 우선)
- **속도**: ~13s/image
- **한국어**: 약간 더 정확 (대표자명 등)
- **설치**: `pip install paddlepaddle paddleocr` (Python 3.11 필요)
- **장점**: 일부 필드 인식 정확도 높음
- **한계**: 속도가 느림

### Tesseract (폴백)
- `brew install tesseract tesseract-lang` 후 `pip install pytesseract`

## Optimized Parameters (EasyOCR)

오토리서치 결과 최적 파라미터 (2026-03-27, 56회 실험):
- `canvas_size=1024` — 기본값 대비 27% 빠름
- GPU/MPS 사용 시 오히려 34% 느려짐 → CPU 모드 권장

## Capabilities

1. **OCR 추출** — 한국어 영수증 이미지에서 텍스트 추출
2. **PDF 추출** — opendataloader-pdf로 PDF 영수증 고정밀 추출
3. **데이터 파싱** — 상호명, 날짜, 품목, 금액 등 구조화
4. **CSV 내보내기** — 로컬 CSV 파일로 저장
5. **Google Sheets 내보내기** — gspread 시트 연동
6. **배치 처리** — 여러 영수증 일괄 처리

## Agent Instructions

사용자가 영수증 처리를 요청하면:

1. 이미지를 받아 `ocr_extract.py` 실행
2. 결과에서 핵심 필드 추출 (상호명, 사업자번호, 금액, 품목, 결제수단)
3. 사용자에게 정리된 결과 전달
4. CSV/Sheets 내보내기가 필요하면 `export_csv.py` 실행

## Output Format

```json
{
  "image_path": "...",
  "engine": "easyocr",
  "entries": [
    {"text": "스타벅스 강남점", "confidence": 0.95, "bbox": [[x,y],...]}
  ],
  "full_text": "추출된 전체 텍스트..."
}
```

## Dependencies

- Python 3.11+
- **EasyOCR** (기본): `pip install easyocr`
- **PaddleOCR** (옵션): `pip install paddlepaddle paddleocr`
- **Tesseract** (옵션): `brew install tesseract tesseract-lang && pip install pytesseract`
- **PDF 추출** (옵션): Java 21+ + `pip install opendataloader-pdf`
- **Google Sheets** (옵션): `pip install gspread google-auth`

## References

- `references/ocr_setup_guide.md` — OCR 엔진별 설치 가이드
- `references/opendataloader_pdf_setup.md` — opendataloader-pdf 설치
- `references/gsheet_oauth_setup.md` — Google Sheets OAuth2 설정
- `references/receipt_field_mapping.md` — 영수증 필드 매핑
