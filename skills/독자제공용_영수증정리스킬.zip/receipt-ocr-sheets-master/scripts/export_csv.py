#!/usr/bin/env python3
"""파싱된 영수증 데이터를 CSV로 내보내기.

두 가지 모드:
1. 요약 모드 (기본): 영수증당 1행 (상호명, 날짜, 총액 등)
2. 상세 모드 (--detail): 품목당 1행
"""

import argparse
import csv
import json
import sys
from pathlib import Path


SUMMARY_HEADERS = [
    "상호명", "날짜", "시간", "품목수", "소계", "부가세", "총금액",
    "결제수단", "카드번호", "이미지경로"
]

DETAIL_HEADERS = [
    "상호명", "날짜", "시간", "품목명", "수량", "단가", "금액",
    "총금액", "결제수단", "이미지경로"
]


def receipt_to_summary_row(receipt: dict) -> list:
    """영수증 1건을 요약 행으로 변환."""
    return [
        receipt.get("store_name", ""),
        receipt.get("date", ""),
        receipt.get("time", ""),
        len(receipt.get("items", [])),
        receipt.get("subtotal", ""),
        receipt.get("tax", ""),
        receipt.get("total", ""),
        receipt.get("payment_method", ""),
        receipt.get("card_number", ""),
        receipt.get("image_path", ""),
    ]


def receipt_to_detail_rows(receipt: dict) -> list[list]:
    """영수증 1건을 품목별 상세 행으로 변환."""
    rows = []
    items = receipt.get("items", [])
    if not items:
        # 품목이 없어도 총액 행은 생성
        rows.append([
            receipt.get("store_name", ""),
            receipt.get("date", ""),
            receipt.get("time", ""),
            "(품목 없음)",
            "", "", "",
            receipt.get("total", ""),
            receipt.get("payment_method", ""),
            receipt.get("image_path", ""),
        ])
    else:
        for item in items:
            rows.append([
                receipt.get("store_name", ""),
                receipt.get("date", ""),
                receipt.get("time", ""),
                item.get("name", ""),
                item.get("quantity", ""),
                item.get("unit_price", ""),
                item.get("amount", ""),
                receipt.get("total", ""),
                receipt.get("payment_method", ""),
                receipt.get("image_path", ""),
            ])
    return rows


def export_csv(receipts: list[dict], output_path: str, detail: bool = False):
    """영수증 목록을 CSV로 내보내기.

    Args:
        receipts: 파싱된 영수증 데이터 리스트
        output_path: CSV 저장 경로
        detail: True면 품목별 상세, False면 영수증별 요약
    """
    headers = DETAIL_HEADERS if detail else SUMMARY_HEADERS

    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow(headers)

        for receipt in receipts:
            if detail:
                rows = receipt_to_detail_rows(receipt)
                writer.writerows(rows)
            else:
                row = receipt_to_summary_row(receipt)
                writer.writerow(row)

    print(f"CSV 저장 완료: {output_path} ({len(receipts)}건)")


def main():
    parser = argparse.ArgumentParser(description="영수증 데이터를 CSV로 내보내기")
    parser.add_argument(
        "input",
        help="파싱된 영수증 JSON 파일 (단일 객체 또는 배열)"
    )
    parser.add_argument(
        "--output", "-o",
        default="receipts.csv",
        help="CSV 출력 경로 (기본: receipts.csv)"
    )
    parser.add_argument(
        "--detail", action="store_true",
        help="품목별 상세 모드 (기본은 영수증별 요약)"
    )
    args = parser.parse_args()

    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = [data]

    export_csv(data, args.output, detail=args.detail)


if __name__ == "__main__":
    main()
