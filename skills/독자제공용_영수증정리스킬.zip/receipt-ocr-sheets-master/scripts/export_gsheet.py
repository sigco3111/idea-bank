#!/usr/bin/env python3
"""파싱된 영수증 데이터를 Google Sheets로 내보내기.

gspread + OAuth2 서비스 계정을 사용합니다.
"""

import argparse
import json
import sys
from pathlib import Path

try:
    import gspread
    from google.oauth2.service_account import Credentials
    GSPREAD_AVAILABLE = True
except ImportError:
    GSPREAD_AVAILABLE = False


SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]

SUMMARY_HEADERS = [
    "상호명", "날짜", "시간", "품목수", "소계", "부가세", "총금액",
    "결제수단", "카드번호", "이미지경로"
]

DETAIL_HEADERS = [
    "상호명", "날짜", "시간", "품목명", "수량", "단가", "금액",
    "총금액", "결제수단", "이미지경로"
]


def get_gspread_client(credentials_path: str) -> "gspread.Client":
    """서비스 계정 인증으로 gspread 클라이언트 생성."""
    creds = Credentials.from_service_account_file(credentials_path, scopes=SCOPES)
    return gspread.authorize(creds)


def receipt_to_summary_row(receipt: dict) -> list:
    """영수증을 요약 행으로 변환."""
    return [
        receipt.get("store_name", ""),
        receipt.get("date", ""),
        receipt.get("time", ""),
        len(receipt.get("items", [])),
        receipt.get("subtotal", ""),
        receipt.get("tax", ""),
        receipt.get("total", ""),
        receipt.get("payment_method", ""),
        receipt.get("card_number", ""),
        receipt.get("image_path", ""),
    ]


def receipt_to_detail_rows(receipt: dict) -> list[list]:
    """영수증을 품목별 상세 행으로 변환."""
    rows = []
    for item in receipt.get("items", []):
        rows.append([
            receipt.get("store_name", ""),
            receipt.get("date", ""),
            receipt.get("time", ""),
            item.get("name", ""),
            item.get("quantity", ""),
            item.get("unit_price", ""),
            item.get("amount", ""),
            receipt.get("total", ""),
            receipt.get("payment_method", ""),
            receipt.get("image_path", ""),
        ])
    if not rows:
        rows.append([
            receipt.get("store_name", ""),
            receipt.get("date", ""),
            receipt.get("time", ""),
            "(품목 없음)", "", "", "",
            receipt.get("total", ""),
            receipt.get("payment_method", ""),
            receipt.get("image_path", ""),
        ])
    return rows


def export_to_gsheet(
    receipts: list[dict],
    spreadsheet_name: str,
    credentials_path: str,
    worksheet_name: str = "영수증",
    detail: bool = False,
    append: bool = False,
):
    """영수증 데이터를 Google Sheets로 내보내기.

    Args:
        receipts: 파싱된 영수증 리스트
        spreadsheet_name: 스프레드시트 이름 (없으면 새로 생성)
        credentials_path: 서비스 계정 JSON 경로
        worksheet_name: 워크시트 이름
        detail: True면 품목별 상세 모드
        append: True면 기존 데이터에 추가
    """
    if not GSPREAD_AVAILABLE:
        print("gspread가 설치되지 않았습니다.", file=sys.stderr)
        print("설치: pip install gspread google-auth", file=sys.stderr)
        sys.exit(1)

    client = get_gspread_client(credentials_path)
    headers = DETAIL_HEADERS if detail else SUMMARY_HEADERS

    # 스프레드시트 열기 또는 생성
    try:
        spreadsheet = client.open(spreadsheet_name)
        print(f"기존 스프레드시트 열기: {spreadsheet_name}")
    except gspread.SpreadsheetNotFound:
        spreadsheet = client.create(spreadsheet_name)
        print(f"새 스프레드시트 생성: {spreadsheet_name}")
        # 첫 번째 시트의 이름 변경은 아래에서 처리

    # 워크시트 열기 또는 생성
    try:
        worksheet = spreadsheet.worksheet(worksheet_name)
    except gspread.WorksheetNotFound:
        worksheet = spreadsheet.add_worksheet(
            title=worksheet_name, rows=1000, cols=len(headers)
        )

    # 데이터 준비
    all_rows = []
    for receipt in receipts:
        if detail:
            all_rows.extend(receipt_to_detail_rows(receipt))
        else:
            all_rows.append(receipt_to_summary_row(receipt))

    if append:
        # 기존 데이터 끝에 추가
        existing = worksheet.get_all_values()
        if not existing:
            # 빈 시트면 헤더 추가
            worksheet.append_row(headers)
        for row in all_rows:
            worksheet.append_row(row)
    else:
        # 시트 초기화 후 새로 쓰기
        worksheet.clear()
        worksheet.append_row(headers)
        for row in all_rows:
            worksheet.append_row(row)

    # 헤더 행 서식 (굵게)
    worksheet.format("1:1", {"textFormat": {"bold": True}})

    url = spreadsheet.url
    print(f"Google Sheets 내보내기 완료: {url}")
    print(f"  - 영수증 {len(receipts)}건, 행 {len(all_rows)}개")
    return url


def main():
    parser = argparse.ArgumentParser(description="영수증 데이터를 Google Sheets로 내보내기")
    parser.add_argument("input", help="파싱된 영수증 JSON 파일")
    parser.add_argument(
        "--spreadsheet", "-s",
        default="영수증 정리",
        help="스프레드시트 이름 (기본: '영수증 정리')"
    )
    parser.add_argument(
        "--worksheet", "-w",
        default="영수증",
        help="워크시트 이름 (기본: '영수증')"
    )
    parser.add_argument(
        "--credentials", "-c",
        required=True,
        help="서비스 계정 JSON 파일 경로"
    )
    parser.add_argument("--detail", action="store_true", help="품목별 상세 모드")
    parser.add_argument("--append", action="store_true", help="기존 데이터에 추가")
    args = parser.parse_args()

    data = json.loads(Path(args.input).read_text(encoding="utf-8"))
    if isinstance(data, dict):
        data = [data]

    export_to_gsheet(
        data,
        spreadsheet_name=args.spreadsheet,
        credentials_path=args.credentials,
        worksheet_name=args.worksheet,
        detail=args.detail,
        append=args.append,
    )


if __name__ == "__main__":
    main()
