#!/usr/bin/env python3
"""OCR 추출 텍스트를 구조화된 영수증 데이터로 파싱.

한국 영수증의 일반적인 형식을 기반으로 필드를 추출합니다.
"""

import argparse
import json
import re
import sys
from pathlib import Path
from datetime import datetime


def normalize_text(text: str) -> str:
    """텍스트 정규화 (공백 정리, 특수문자 처리)."""
    text = re.sub(r"\s+", " ", text).strip()
    return text


def extract_store_name(lines: list[str]) -> str | None:
    """상호명 추출. 보통 영수증 상단에 위치."""
    # 상호 / 가맹점명 패턴
    for line in lines[:10]:  # 상단 10줄 내 탐색
        m = re.search(r"(?:상\s*호|가맹점)\s*[:\s]*(.+)", line)
        if m:
            return m.group(1).strip()
    # 첫 줄이 상호명인 경우가 많음 (패턴 매칭 실패 시)
    for line in lines[:5]:
        cleaned = line.strip()
        if cleaned and not re.match(r"^[\d\-:/\s]+$", cleaned):
            return cleaned
    return None


def extract_datetime(lines: list[str]) -> tuple[str | None, str | None]:
    """거래 일시 추출. (date, time) 반환."""
    full_text = "\n".join(lines)

    # YYYY-MM-DD HH:MM:SS or YYYY/MM/DD HH:MM
    m = re.search(
        r"(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?",
        full_text
    )
    if m:
        y, mo, d = m.group(1), m.group(2).zfill(2), m.group(3).zfill(2)
        h, mi = m.group(4).zfill(2), m.group(5)
        return f"{y}-{mo}-{d}", f"{h}:{mi}"

    # 날짜만 있는 경우
    m = re.search(r"(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})", full_text)
    if m:
        y, mo, d = m.group(1), m.group(2).zfill(2), m.group(3).zfill(2)
        return f"{y}-{mo}-{d}", None

    return None, None


def parse_amount(text: str) -> int | None:
    """금액 문자열에서 숫자 추출. '9,000원' -> 9000"""
    cleaned = re.sub(r"[^\d]", "", text)
    if cleaned:
        return int(cleaned)
    return None


def extract_items(lines: list[str]) -> list[dict]:
    """품목 목록 추출.

    일반적인 영수증 품목 형식:
    - 품목명  수량  단가  금액
    - 품목명  금액
    """
    items = []

    # 패턴 1: 품목명 수량 단가 금액 (탭/공백 구분)
    # 예: "아메리카노  2  4,500  9,000"
    pattern_full = re.compile(
        r"(.+?)\s+(\d+)\s+([\d,]+)\s+([\d,]+)"
    )

    # 패턴 2: 품목명  금액
    # 예: "아메리카노  9,000"
    pattern_simple = re.compile(
        r"(.+?)\s+([\d,]+)\s*원?\s*$"
    )

    # 품목 시작/끝 영역 감지
    in_items = False
    skip_keywords = {"합계", "총", "부가세", "과세", "면세", "거스름", "카드", "현금", "승인"}

    for line in lines:
        normalized = normalize_text(line)

        # 품목 영역 시작 감지
        if re.search(r"품\s*목|상품명|메뉴", normalized):
            in_items = True
            continue

        # 합계/결제 영역 도달 시 종료
        if re.search(r"합\s*계|총\s*금?\s*액|결\s*제|total", normalized, re.IGNORECASE):
            in_items = False
            continue

        if not in_items and not items:
            # 아직 품목 영역 진입 전이면 패턴 매칭 시도
            pass

        # 건너뛸 키워드
        if any(kw in normalized for kw in skip_keywords):
            continue

        # 패턴 매칭
        m = pattern_full.match(normalized)
        if m:
            name = m.group(1).strip()
            qty = int(m.group(2))
            unit_price = parse_amount(m.group(3))
            amount = parse_amount(m.group(4))
            if name and amount:
                items.append({
                    "name": name,
                    "quantity": qty,
                    "unit_price": unit_price,
                    "amount": amount,
                })
                continue

        m = pattern_simple.match(normalized)
        if m:
            name = m.group(1).strip()
            amount = parse_amount(m.group(2))
            # 필터: 이름이 너무 짧거나 숫자로만 구성된 경우 건너뜀
            if name and amount and len(name) > 1 and not name.isdigit():
                items.append({
                    "name": name,
                    "quantity": 1,
                    "unit_price": amount,
                    "amount": amount,
                })

    return items


def extract_total(lines: list[str]) -> int | None:
    """총 금액 추출."""
    for line in lines:
        m = re.search(r"(?:합\s*계|총\s*금?\s*액|total)\s*[:\s]*([\d,]+)", line, re.IGNORECASE)
        if m:
            return parse_amount(m.group(1))
    return None


def extract_tax(lines: list[str]) -> int | None:
    """부가세 추출."""
    for line in lines:
        m = re.search(r"(?:부가\s*세|VAT|세\s*금)\s*[:\s]*([\d,]+)", line, re.IGNORECASE)
        if m:
            return parse_amount(m.group(1))
    return None


def extract_payment_method(lines: list[str]) -> str | None:
    """결제 수단 추출."""
    full_text = "\n".join(lines)
    if re.search(r"신용\s*카드|credit", full_text, re.IGNORECASE):
        return "신용카드"
    if re.search(r"체크\s*카드|debit", full_text, re.IGNORECASE):
        return "체크카드"
    if re.search(r"현\s*금|cash", full_text, re.IGNORECASE):
        return "현금"
    if re.search(r"카카오\s*페이|kakaopay", full_text, re.IGNORECASE):
        return "카카오페이"
    if re.search(r"네이버\s*페이|naverpay", full_text, re.IGNORECASE):
        return "네이버페이"
    if re.search(r"삼성\s*페이|samsung\s*pay", full_text, re.IGNORECASE):
        return "삼성페이"
    if re.search(r"카드", full_text):
        return "카드"
    return None


def extract_card_number(lines: list[str]) -> str | None:
    """카드번호 추출 (마스킹된 형태)."""
    for line in lines:
        m = re.search(r"(\d{4}[\-*]+[\d*\-]+\d{4})", line)
        if m:
            return m.group(1)
    return None


def parse_receipt(ocr_result: dict) -> dict:
    """OCR 결과를 구조화된 영수증 데이터로 파싱.

    Args:
        ocr_result: ocr_extract.py의 출력 JSON

    Returns:
        구조화된 영수증 데이터
    """
    full_text = ocr_result.get("full_text", "")
    lines = full_text.split("\n")

    store_name = extract_store_name(lines)
    date, time = extract_datetime(lines)
    items = extract_items(lines)
    total = extract_total(lines)
    tax = extract_tax(lines)
    payment_method = extract_payment_method(lines)
    card_number = extract_card_number(lines)

    # total이 없으면 items 합산
    if total is None and items:
        total = sum(item["amount"] for item in items)

    # subtotal 계산
    subtotal = total
    if tax and total:
        subtotal = total - tax

    return {
        "store_name": store_name,
        "date": date,
        "time": time,
        "items": items,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "payment_method": payment_method,
        "card_number": card_number,
        "image_path": ocr_result.get("image_path"),
        "ocr_engine": ocr_result.get("engine"),
        "raw_text": full_text,
    }


def main():
    parser = argparse.ArgumentParser(description="OCR 결과를 구조화된 영수증 데이터로 파싱")
    parser.add_argument("input", help="OCR 결과 JSON 파일 경로 (또는 - 로 stdin)")
    parser.add_argument("--output", "-o", help="결과 JSON 저장 경로")
    args = parser.parse_args()

    if args.input == "-":
        ocr_result = json.load(sys.stdin)
    else:
        ocr_result = json.loads(Path(args.input).read_text(encoding="utf-8"))

    receipt = parse_receipt(ocr_result)
    output = json.dumps(receipt, ensure_ascii=False, indent=2)

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"결과 저장: {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
