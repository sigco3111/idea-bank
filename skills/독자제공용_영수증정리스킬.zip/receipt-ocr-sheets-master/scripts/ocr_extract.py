#!/usr/bin/env python3
"""영수증 이미지에서 OCR로 텍스트를 추출하는 스크립트.

사용 가능한 OCR 엔진을 자동 감지하여 한국어 텍스트를 추출합니다.
"""

import argparse
import json
import sys
from pathlib import Path

from PIL import Image


def ocr_with_easyocr(image_path: str) -> list[dict]:
    """EasyOCR로 텍스트 추출."""
    import easyocr
    reader = easyocr.Reader(["ko", "en"], gpu=False)
    results = reader.readtext(image_path, canvas_size=1024)
    # results: list of (bbox, text, confidence)
    return [
        {
            "text": text,
            "confidence": float(conf),
            "bbox": [[int(p[0]), int(p[1])] for p in bbox],
        }
        for bbox, text, conf in results
    ]


def ocr_with_paddleocr(image_path: str) -> list[dict]:
    """PaddleOCR로 텍스트 추출 (v3+ API)."""
    from paddleocr import PaddleOCR
    import logging
    logging.getLogger("ppocr").setLevel(logging.WARNING)
    logging.getLogger("paddleslim").setLevel(logging.WARNING)
    ocr = PaddleOCR(use_textline_orientation=True, lang="korean")
    result = ocr.predict(image_path)
    entries = []
    for res in result:
        texts = res.get("rec_texts", [])
        scores = res.get("rec_scores", [])
        polys = res.get("rec_polys", [])
        for i, text in enumerate(texts):
            conf = float(scores[i]) if i < len(scores) else 0.0
            bbox = []
            if i < len(polys):
                for pt in polys[i]:
                    bbox.append([int(pt[0]), int(pt[1])])
            entries.append({"text": text, "confidence": conf, "bbox": bbox})
    return entries


def ocr_with_tesseract(image_path: str) -> list[dict]:
    """Tesseract로 텍스트 추출."""
    import pytesseract
    img = Image.open(image_path)
    # 한국어 + 영어 OCR
    data = pytesseract.image_to_data(
        img, lang="kor+eng", output_type=pytesseract.Output.DICT
    )
    entries = []
    for i, text in enumerate(data["text"]):
        text = text.strip()
        if not text:
            continue
        conf = int(data["conf"][i])
        if conf < 0:
            continue
        entries.append({
            "text": text,
            "confidence": conf / 100.0,
            "bbox": [
                [data["left"][i], data["top"][i]],
                [data["left"][i] + data["width"][i], data["top"][i]],
                [data["left"][i] + data["width"][i], data["top"][i] + data["height"][i]],
                [data["left"][i], data["top"][i] + data["height"][i]],
            ],
        })
    return entries


def detect_engine():
    """사용 가능한 OCR 엔진 감지."""
    try:
        import easyocr  # noqa: F401
        return "easyocr"
    except ImportError:
        pass
    try:
        from paddleocr import PaddleOCR  # noqa: F401
        return "paddleocr"
    except ImportError:
        pass
    try:
        import pytesseract  # noqa: F401
        return "tesseract"
    except ImportError:
        pass
    return None


def extract_text(image_path: str, engine: str = None) -> dict:
    """이미지에서 텍스트 추출 (엔진 자동 감지 또는 지정).

    Returns:
        {
            "image_path": str,
            "engine": str,
            "entries": [{"text": str, "confidence": float, "bbox": list}],
            "full_text": str  # 모든 텍스트를 줄바꿈으로 연결
        }
    """
    if engine is None:
        engine = detect_engine()
    if engine is None:
        raise RuntimeError(
            "사용 가능한 OCR 엔진이 없습니다. "
            "python scripts/setup_ocr.py --engine easyocr 로 설치하세요."
        )

    # 이미지 유효성 확인
    img = Image.open(image_path)
    img.verify()

    ocr_fn = {
        "easyocr": ocr_with_easyocr,
        "paddleocr": ocr_with_paddleocr,
        "tesseract": ocr_with_tesseract,
    }[engine]

    entries = ocr_fn(image_path)

    # bbox의 y좌표 기준으로 정렬 (위에서 아래로)
    entries.sort(key=lambda e: e["bbox"][0][1] if e["bbox"] else 0)

    full_text = "\n".join(e["text"] for e in entries)

    return {
        "image_path": str(Path(image_path).resolve()),
        "engine": engine,
        "entries": entries,
        "full_text": full_text,
    }


def main():
    parser = argparse.ArgumentParser(description="영수증 이미지 OCR 텍스트 추출")
    parser.add_argument("image", help="영수증 이미지 파일 경로")
    parser.add_argument(
        "--engine",
        choices=["easyocr", "paddleocr", "tesseract"],
        help="사용할 OCR 엔진 (미지정 시 자동 감지)"
    )
    parser.add_argument(
        "--output", "-o",
        help="결과 JSON 저장 경로 (미지정 시 stdout)"
    )
    args = parser.parse_args()

    if not Path(args.image).exists():
        print(f"파일을 찾을 수 없습니다: {args.image}", file=sys.stderr)
        sys.exit(1)

    result = extract_text(args.image, engine=args.engine)

    output = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"결과 저장: {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
