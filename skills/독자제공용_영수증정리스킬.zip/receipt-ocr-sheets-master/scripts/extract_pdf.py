#!/usr/bin/env python3
"""opendataloader-pdf를 이용한 영수증 PDF 데이터 추출.

PDF 영수증에서 텍스트와 테이블을 고정밀도로 추출합니다.
이미지 기반 OCR보다 테이블 구조 인식이 뛰어나며 (정확도 0.93),
한국어 텍스트를 왜곡 없이 추출합니다.

요구사항:
    - Java 21+ (brew install openjdk@21)
    - opendataloader-pdf (pip install opendataloader-pdf)
"""

import argparse
import json
import os
import re
import sys
import tempfile
from pathlib import Path


def check_java():
    """Java 설치 여부 확인."""
    import shutil
    if not shutil.which("java"):
        java_home = os.environ.get("JAVA_HOME", "")
        java_bin = os.path.join(java_home, "bin", "java") if java_home else ""
        if not (java_bin and os.path.exists(java_bin)):
            print("오류: Java가 설치되지 않았습니다.", file=sys.stderr)
            print("  brew install openjdk@21", file=sys.stderr)
            print("  export JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home", file=sys.stderr)
            return False
    return True


def extract_pdf(input_path: str, output_dir: str | None = None) -> dict:
    """PDF에서 영수증 데이터를 추출.

    Args:
        input_path: PDF 파일 경로
        output_dir: 출력 디렉토리 (None이면 임시 디렉토리 사용)

    Returns:
        opendataloader-pdf JSON 결과와 파싱된 영수증 데이터
    """
    import opendataloader_pdf

    if output_dir is None:
        output_dir = tempfile.mkdtemp(prefix="receipt_pdf_")

    os.makedirs(output_dir, exist_ok=True)

    opendataloader_pdf.convert(
        input_path=[input_path],
        output_dir=output_dir,
        format="markdown,json"
    )

    # JSON 결과 읽기
    stem = Path(input_path).stem
    json_path = os.path.join(output_dir, f"{stem}.json")
    md_path = os.path.join(output_dir, f"{stem}.md")

    raw_json = {}
    if os.path.exists(json_path):
        with open(json_path, "r", encoding="utf-8") as f:
            raw_json = json.load(f)

    markdown_text = ""
    if os.path.exists(md_path):
        with open(md_path, "r", encoding="utf-8") as f:
            markdown_text = f.read()

    # 구조화된 데이터로 변환
    receipt = parse_pdf_result(raw_json, markdown_text, input_path)
    receipt["_raw_json"] = raw_json
    receipt["_markdown"] = markdown_text
    receipt["_output_dir"] = output_dir

    return receipt


def _clean_separators(text: str) -> str:
    """영수증 구분선 문자(=, -) 제거 후 정리."""
    text = re.sub(r"[=]{3,}", "\n", text)
    text = re.sub(r"[-]{3,}", "\n", text)
    return text.strip()


def extract_text_from_kids(kids: list[dict]) -> str:
    """JSON kids 배열에서 전체 텍스트 추출.

    opendataloader-pdf가 여러 줄을 하나의 paragraph로 합치는 경우가 있으므로,
    구분선 문자(===, ---)를 줄바꿈으로 변환합니다.
    """
    texts = []
    for kid in kids:
        if "content" in kid:
            # 구분선 문자로 줄바꿈 복원
            content = _clean_separators(kid["content"])
            # 알려진 패턴으로 줄바꿈 삽입 (품목 행 분리)
            content = _split_item_lines(content)
            texts.append(content)
        if "rows" in kid:
            for row in kid["rows"]:
                for cell in row.get("cells", []):
                    for cell_kid in cell.get("kids", []):
                        if "content" in cell_kid:
                            texts.append(cell_kid["content"])
    return "\n".join(texts)


def _split_item_lines(text: str) -> str:
    """한 줄에 합쳐진 품목 행들을 분리.

    예: '삼각김밥 1 1,500 1,500 컵라면 2 1,200 2,400' →
        '삼각김밥 1 1,500 1,500\n컵라면 2 1,200 2,400'
    """
    # 패턴: 금액(숫자,숫자) 다음에 한글이 오면 줄바꿈 삽입
    text = re.sub(r"([\d,]+)\s+([\uac00-\ud7a3])", r"\1\n\2", text)
    # 키워드 앞에 줄바꿈: 소계, 부가세, 합계, 결제수단, 카드번호, 승인번호
    text = re.sub(r"\s+(소계|부가세|합계|결제수단|카드번호|승인번호)", r"\n\1", text)
    return text


def extract_table_items(kids: list[dict]) -> list[dict]:
    """JSON 테이블 구조에서 품목 목록 추출."""
    items = []

    for kid in kids:
        if kid.get("type") != "table":
            continue

        rows = kid.get("rows", [])
        if len(rows) < 2:
            continue

        # 헤더 행에서 컬럼 매핑 파악
        header_row = rows[0]
        header_texts = []
        for cell in header_row.get("cells", []):
            cell_text = ""
            for ck in cell.get("kids", []):
                cell_text += ck.get("content", "")
            header_texts.append(cell_text.strip())

        # 컬럼 인덱스 매핑
        col_map = {}
        for i, h in enumerate(header_texts):
            h_lower = h.lower()
            if any(k in h_lower for k in ["품목", "상품", "메뉴", "item"]):
                col_map["name"] = i
            elif any(k in h_lower for k in ["수량", "qty", "quantity"]):
                col_map["qty"] = i
            elif any(k in h_lower for k in ["단가", "unit", "price"]):
                col_map["unit_price"] = i
            elif any(k in h_lower for k in ["금액", "amount", "합계"]):
                col_map["amount"] = i

        # 데이터 행 파싱
        for row in rows[1:]:
            cells = row.get("cells", [])
            cell_texts = []
            for cell in cells:
                cell_text = ""
                for ck in cell.get("kids", []):
                    cell_text += ck.get("content", "")
                cell_texts.append(cell_text.strip())

            item = {}
            if "name" in col_map and col_map["name"] < len(cell_texts):
                item["name"] = cell_texts[col_map["name"]]
            if "qty" in col_map and col_map["qty"] < len(cell_texts):
                try:
                    item["quantity"] = int(re.sub(r"[^\d]", "", cell_texts[col_map["qty"]]))
                except ValueError:
                    item["quantity"] = 1
            else:
                item["quantity"] = 1
            if "unit_price" in col_map and col_map["unit_price"] < len(cell_texts):
                item["unit_price"] = _parse_amount(cell_texts[col_map["unit_price"]])
            if "amount" in col_map and col_map["amount"] < len(cell_texts):
                item["amount"] = _parse_amount(cell_texts[col_map["amount"]])
            elif "unit_price" in item and item.get("unit_price"):
                item["amount"] = item["unit_price"] * item.get("quantity", 1)

            if item.get("name") and item.get("amount"):
                items.append(item)

    return items


def _parse_amount(text: str) -> int | None:
    """금액 문자열에서 숫자 추출."""
    cleaned = re.sub(r"[^\d]", "", text)
    return int(cleaned) if cleaned else None


def parse_pdf_result(raw_json: dict, markdown_text: str, input_path: str) -> dict:
    """opendataloader-pdf 결과를 영수증 형식으로 파싱."""
    kids = raw_json.get("kids", [])
    full_text = extract_text_from_kids(kids)
    lines = full_text.split("\n")

    # 테이블에서 품목 추출 시도
    items = extract_table_items(kids)

    # 테이블이 없으면 텍스트에서 품목 추출 (기존 parse_receipt 로직 활용)
    if not items:
        items = _extract_items_from_text(lines)

    # 상호명
    store_name = _extract_store_name(lines)

    # 날짜/시간
    date, time = _extract_datetime(lines)

    # 합계
    total = _extract_total(lines)

    # 부가세
    tax = _extract_tax(lines)

    # 결제수단
    payment_method = _extract_payment_method(full_text)

    # 카드번호
    card_number = _extract_card_number(lines)

    if total is None and items:
        total = sum(item.get("amount", 0) for item in items)

    subtotal = total
    if tax and total:
        subtotal = total - tax

    return {
        "store_name": store_name,
        "date": date,
        "time": time,
        "items": items,
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "payment_method": payment_method,
        "card_number": card_number,
        "source_path": input_path,
        "extraction_engine": "opendataloader-pdf",
        "raw_text": full_text,
    }


def _extract_store_name(lines: list[str]) -> str | None:
    for line in lines[:10]:
        m = re.search(r"(?:상\s*호|가맹점)\s*[:\s]*(.+)", line)
        if m:
            return m.group(1).strip()
    for line in lines[:5]:
        cleaned = re.sub(r"[=\-]+", "", line).strip()
        if cleaned and not re.match(r"^[\d\-:/\s]+$", cleaned):
            # 날짜 정보가 붙어 있으면 제거
            cleaned = re.sub(r"\s*날짜.*$", "", cleaned).strip()
            if cleaned:
                return cleaned
    return None


def _extract_datetime(lines: list[str]) -> tuple[str | None, str | None]:
    full_text = "\n".join(lines)
    m = re.search(
        r"(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?",
        full_text,
    )
    if m:
        y, mo, d = m.group(1), m.group(2).zfill(2), m.group(3).zfill(2)
        h, mi = m.group(4).zfill(2), m.group(5)
        return f"{y}-{mo}-{d}", f"{h}:{mi}"

    m = re.search(r"(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})", full_text)
    if m:
        y, mo, d = m.group(1), m.group(2).zfill(2), m.group(3).zfill(2)
        return f"{y}-{mo}-{d}", None

    return None, None


def _extract_total(lines: list[str]) -> int | None:
    for line in lines:
        m = re.search(r"(?:합\s*계|총\s*금?\s*액|total)\s*[:\s]*([\d,]+)", line, re.IGNORECASE)
        if m:
            return _parse_amount(m.group(1))
    return None


def _extract_tax(lines: list[str]) -> int | None:
    for line in lines:
        m = re.search(r"(?:부가\s*세|VAT|세\s*금)\s*[:\s]*([\d,]+)", line, re.IGNORECASE)
        if m:
            return _parse_amount(m.group(1))
    return None


def _extract_payment_method(text: str) -> str | None:
    if re.search(r"신용\s*카드|credit", text, re.IGNORECASE):
        return "신용카드"
    if re.search(r"체크\s*카드|debit", text, re.IGNORECASE):
        return "체크카드"
    if re.search(r"현\s*금|cash", text, re.IGNORECASE):
        return "현금"
    if re.search(r"카카오\s*페이", text, re.IGNORECASE):
        return "카카오페이"
    if re.search(r"네이버\s*페이", text, re.IGNORECASE):
        return "네이버페이"
    if re.search(r"삼성\s*페이", text, re.IGNORECASE):
        return "삼성페이"
    if re.search(r"카드", text):
        return "카드"
    return None


def _extract_card_number(lines: list[str]) -> str | None:
    for line in lines:
        m = re.search(r"(\d{4}[\-*]+[\d*\-]+\d{4})", line)
        if m:
            return m.group(1)
    return None


def _extract_items_from_text(lines: list[str]) -> list[dict]:
    """텍스트에서 품목 추출 (테이블이 없는 경우 폴백)."""
    items = []
    pattern_full = re.compile(r"(.+?)\s+(\d+)\s+([\d,]+)\s+([\d,]+)")
    pattern_simple = re.compile(r"(.+?)\s+([\d,]+)\s*원?\s*$")
    skip_keywords = {"합계", "총", "부가세", "과세", "면세", "거스름", "카드", "현금", "승인", "소계"}

    in_items = False
    for line in lines:
        normalized = re.sub(r"\s+", " ", line).strip()
        if not normalized:
            continue

        if re.search(r"품\s*목|상품명|메뉴", normalized):
            in_items = True
            continue
        if re.search(r"합\s*계|총\s*금?\s*액|결\s*제|total", normalized, re.IGNORECASE):
            break

        if any(kw in normalized for kw in skip_keywords):
            continue

        m = pattern_full.match(normalized)
        if m:
            name = m.group(1).strip()
            qty = int(m.group(2))
            unit_price = _parse_amount(m.group(3))
            amount = _parse_amount(m.group(4))
            if name and amount:
                items.append({"name": name, "quantity": qty, "unit_price": unit_price, "amount": amount})
                continue

        if in_items:
            m = pattern_simple.match(normalized)
            if m:
                name = m.group(1).strip()
                amount = _parse_amount(m.group(2))
                if name and amount and len(name) > 1 and not name.isdigit():
                    items.append({"name": name, "quantity": 1, "unit_price": amount, "amount": amount})

    return items


def main():
    parser = argparse.ArgumentParser(
        description="opendataloader-pdf로 영수증 PDF에서 구조화된 데이터 추출"
    )
    parser.add_argument("input", help="영수증 PDF 파일 경로")
    parser.add_argument("--output", "-o", help="결과 JSON 저장 경로")
    parser.add_argument("--output-dir", help="opendataloader-pdf 출력 디렉토리")
    parser.add_argument("--raw", action="store_true", help="원본 JSON도 포함하여 출력")
    args = parser.parse_args()

    if not check_java():
        sys.exit(1)

    try:
        import opendataloader_pdf  # noqa: F401
    except ImportError:
        print("오류: opendataloader-pdf가 설치되지 않았습니다.", file=sys.stderr)
        print("  pip install opendataloader-pdf", file=sys.stderr)
        sys.exit(1)

    result = extract_pdf(args.input, args.output_dir)

    # 출력에서 내부 필드 제거 (--raw가 아니면)
    if not args.raw:
        result.pop("_raw_json", None)
        result.pop("_markdown", None)
        result.pop("_output_dir", None)

    output = json.dumps(result, ensure_ascii=False, indent=2)

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"결과 저장: {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
