#!/usr/bin/env python3
"""여러 영수증 이미지를 일괄 처리.

디렉토리 내 이미지 파일을 모두 OCR → 파싱 → CSV/JSON 내보내기합니다.
"""

import argparse
import json
import sys
from pathlib import Path

# 같은 디렉토리의 모듈 import
sys.path.insert(0, str(Path(__file__).parent))
from ocr_extract import extract_text, detect_engine
from parse_receipt import parse_receipt
from export_csv import export_csv


IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".webp"}


def find_images(directory: str) -> list[Path]:
    """디렉토리에서 이미지 파일 목록 반환."""
    dir_path = Path(directory)
    if not dir_path.is_dir():
        print(f"디렉토리를 찾을 수 없습니다: {directory}", file=sys.stderr)
        sys.exit(1)

    images = []
    for f in sorted(dir_path.iterdir()):
        if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS:
            images.append(f)
    return images


def process_single(image_path: Path, engine: str | None) -> dict | None:
    """단일 이미지 처리: OCR → 파싱."""
    try:
        print(f"  처리 중: {image_path.name} ...", end=" ", flush=True)
        ocr_result = extract_text(str(image_path), engine=engine)
        receipt = parse_receipt(ocr_result)
        print(f"완료 (총액: {receipt.get('total', '?')}원)")
        return receipt
    except Exception as e:
        print(f"오류: {e}")
        return None


def batch_process(
    directory: str,
    engine: str | None = None,
    output_csv: str | None = None,
    output_json: str | None = None,
    detail: bool = False,
) -> list[dict]:
    """디렉토리의 모든 영수증 이미지를 일괄 처리.

    Args:
        directory: 이미지가 있는 디렉토리 경로
        engine: OCR 엔진 (None이면 자동 감지)
        output_csv: CSV 출력 경로 (None이면 생략)
        output_json: JSON 출력 경로 (None이면 생략)
        detail: CSV 상세 모드 여부

    Returns:
        파싱된 영수증 데이터 리스트
    """
    images = find_images(directory)
    if not images:
        print(f"이미지 파일을 찾을 수 없습니다: {directory}")
        return []

    if engine is None:
        engine = detect_engine()
        if engine is None:
            print("사용 가능한 OCR 엔진이 없습니다.", file=sys.stderr)
            print("설치: python scripts/setup_ocr.py --engine easyocr", file=sys.stderr)
            sys.exit(1)

    print(f"OCR 엔진: {engine}")
    print(f"처리할 이미지: {len(images)}개\n")

    receipts = []
    errors = 0
    for img in images:
        result = process_single(img, engine)
        if result:
            receipts.append(result)
        else:
            errors += 1

    print(f"\n=== 처리 결과 ===")
    print(f"  성공: {len(receipts)}건")
    print(f"  실패: {errors}건")

    if receipts:
        total_sum = sum(r.get("total", 0) or 0 for r in receipts)
        print(f"  총 합계: {total_sum:,}원")

    # JSON 내보내기
    if output_json:
        Path(output_json).write_text(
            json.dumps(receipts, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        print(f"\nJSON 저장: {output_json}")

    # CSV 내보내기
    if output_csv:
        export_csv(receipts, output_csv, detail=detail)

    return receipts


def main():
    parser = argparse.ArgumentParser(description="영수증 이미지 일괄 처리")
    parser.add_argument("directory", help="영수증 이미지가 있는 디렉토리")
    parser.add_argument(
        "--engine",
        choices=["easyocr", "paddleocr", "tesseract"],
        help="OCR 엔진 지정"
    )
    parser.add_argument(
        "--output", "-o",
        default="receipts.csv",
        help="CSV 출력 경로 (기본: receipts.csv)"
    )
    parser.add_argument(
        "--json", "-j",
        help="JSON 출력 경로"
    )
    parser.add_argument(
        "--detail", action="store_true",
        help="CSV 품목별 상세 모드"
    )
    args = parser.parse_args()

    batch_process(
        directory=args.directory,
        engine=args.engine,
        output_csv=args.output,
        output_json=args.json,
        detail=args.detail,
    )


if __name__ == "__main__":
    main()
