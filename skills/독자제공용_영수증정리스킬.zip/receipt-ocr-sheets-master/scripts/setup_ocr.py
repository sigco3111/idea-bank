#!/usr/bin/env python3
"""OCR 엔진 설치 및 설정 스크립트.

사용 가능한 OCR 엔진을 감지하고, 필요시 설치합니다.
우선순위: EasyOCR > PaddleOCR > Tesseract
"""

import subprocess
import sys
import shutil
import argparse


def check_easyocr():
    """EasyOCR 사용 가능 여부 확인."""
    try:
        import easyocr  # noqa: F401
        return True
    except ImportError:
        return False


def check_paddleocr():
    """PaddleOCR 사용 가능 여부 확인."""
    try:
        from paddleocr import PaddleOCR  # noqa: F401
        return True
    except ImportError:
        return False


def check_tesseract():
    """Tesseract 사용 가능 여부 확인."""
    if not shutil.which("tesseract"):
        return False
    try:
        import pytesseract  # noqa: F401
        # 한국어 언어팩 확인
        result = subprocess.run(
            ["tesseract", "--list-langs"],
            capture_output=True, text=True
        )
        return "kor" in result.stdout
    except ImportError:
        return False


def detect_available_engine():
    """사용 가능한 OCR 엔진 자동 감지 (우선순위 순)."""
    engines = [
        ("easyocr", check_easyocr),
        ("paddleocr", check_paddleocr),
        ("tesseract", check_tesseract),
    ]
    for name, check_fn in engines:
        if check_fn():
            return name
    return None


def install_engine(engine: str):
    """OCR 엔진 설치."""
    if engine == "easyocr":
        print("EasyOCR 설치 중...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "easyocr"])
        print("EasyOCR 설치 완료. 첫 실행 시 한국어 모델이 다운로드됩니다.")

    elif engine == "paddleocr":
        print("PaddleOCR 설치 중...")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install",
            "paddlepaddle", "paddleocr"
        ])
        print("PaddleOCR 설치 완료.")

    elif engine == "tesseract":
        print("Tesseract 설치 안내:")
        print("  macOS:  brew install tesseract tesseract-lang")
        print("  Ubuntu: sudo apt install tesseract-ocr tesseract-ocr-kor")
        print("  그 후:  pip install pytesseract")
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "pytesseract"
        ])
    else:
        print(f"알 수 없는 엔진: {engine}")
        sys.exit(1)


def install_common_deps():
    """공통 의존성 설치."""
    subprocess.check_call([
        sys.executable, "-m", "pip", "install", "Pillow"
    ])


def status_report():
    """현재 OCR 엔진 상태 출력."""
    print("=== OCR 엔진 상태 ===")
    print(f"  EasyOCR:   {'✓ 사용 가능' if check_easyocr() else '✗ 미설치'}")
    print(f"  PaddleOCR: {'✓ 사용 가능' if check_paddleocr() else '✗ 미설치'}")
    print(f"  Tesseract: {'✓ 사용 가능' if check_tesseract() else '✗ 미설치'}")

    engine = detect_available_engine()
    if engine:
        print(f"\n  현재 사용할 엔진: {engine}")
    else:
        print("\n  ⚠ 사용 가능한 OCR 엔진이 없습니다.")
        print("  설치: python setup_ocr.py --engine easyocr")


def main():
    parser = argparse.ArgumentParser(description="OCR 엔진 설치 및 설정")
    parser.add_argument(
        "--engine",
        choices=["easyocr", "paddleocr", "tesseract"],
        help="설치할 OCR 엔진"
    )
    parser.add_argument(
        "--status", action="store_true",
        help="현재 OCR 엔진 상태 확인"
    )
    args = parser.parse_args()

    if args.status or not args.engine:
        status_report()
        return

    install_common_deps()
    install_engine(args.engine)
    print()
    status_report()


if __name__ == "__main__":
    main()
