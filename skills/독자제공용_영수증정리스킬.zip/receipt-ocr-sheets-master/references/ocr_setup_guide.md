# OCR 엔진 설치 가이드

## 1. EasyOCR (권장)

한국어 인식률이 높고 설치가 간편합니다.

```bash
pip install easyocr
```

- 첫 실행 시 한국어 모델(~100MB)을 자동 다운로드
- GPU(CUDA) 사용 시 `gpu=True` 설정으로 속도 향상
- CPU만으로도 동작 (gpu=False)

## 2. PaddleOCR

높은 정확도, 특히 표 형태의 영수증에 강합니다.

```bash
pip install paddlepaddle paddleocr
```

- macOS (Apple Silicon): `pip install paddlepaddle` (CPU 버전)
- Linux GPU: [PaddlePaddle GPU 설치 가이드](https://www.paddlepaddle.org.cn/install/quick) 참조
- 한국어: `lang="korean"` 설정

## 3. Tesseract (폴백)

시스템 패키지 설치가 필요합니다.

### macOS
```bash
brew install tesseract tesseract-lang
pip install pytesseract
```

### Ubuntu/Debian
```bash
sudo apt install tesseract-ocr tesseract-ocr-kor
pip install pytesseract
```

### 한국어 언어팩 확인
```bash
tesseract --list-langs | grep kor
```

## 공통 의존성

```bash
pip install Pillow
```

## 자동 설정

```bash
python scripts/setup_ocr.py --status    # 현재 상태 확인
python scripts/setup_ocr.py --engine easyocr  # EasyOCR 설치
```
