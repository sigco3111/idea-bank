# opendataloader-pdf 설치 및 사용 가이드

영수증 PDF에서 텍스트와 테이블 구조를 고정밀도로 추출하기 위한 도구입니다.

## 왜 opendataloader-pdf인가?

| 비교 항목 | opendataloader-pdf | EasyOCR (이미지) |
|---|---|---|
| 테이블 정확도 | 0.93 | 테이블 구조 인식 불가 |
| 한국어 정확도 | 100% (텍스트 기반 PDF) | 70-80% (글자 오인식 빈번) |
| 처리 속도 | 빠름 (텍스트 추출) | 느림 (모델 추론) |
| 입력 형식 | PDF 전용 | 이미지 전용 |

**실제 테스트 결과**: 동일한 영수증으로 테스트 시 EasyOCR은 "홍길동"→"훔길동", "컵라면"→"컴라면", "코카콜라500ml"→"코카출라5oOrnil"로 오인식. opendataloader-pdf는 100% 정확.

## 설치

### 1. Java 21 설치 (필수)

```bash
# macOS (Homebrew)
brew install openjdk@21

# 환경변수 설정
export JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home
export PATH="$JAVA_HOME/bin:$PATH"

# 영구 설정 (~/.zshrc 또는 ~/.bashrc에 추가)
echo 'export JAVA_HOME=/opt/homebrew/opt/openjdk@21/libexec/openjdk.jdk/Contents/Home' >> ~/.zshrc
echo 'export PATH="$JAVA_HOME/bin:$PATH"' >> ~/.zshrc
```

### 2. opendataloader-pdf 설치

```bash
pip install opendataloader-pdf
```

## 사용법

### CLI (extract_pdf.py)

```bash
# 기본 사용
python scripts/extract_pdf.py receipt.pdf

# JSON 파일로 저장
python scripts/extract_pdf.py receipt.pdf -o result.json

# 원본 JSON 포함 출력
python scripts/extract_pdf.py receipt.pdf --raw

# 출력 디렉토리 지정
python scripts/extract_pdf.py receipt.pdf --output-dir /tmp/output/
```

### Python API

```python
from scripts.extract_pdf import extract_pdf

result = extract_pdf("receipt.pdf")
print(result["items"])       # 품목 목록
print(result["total"])       # 합계
print(result["store_name"])  # 상호명
```

## 출력 형식

opendataloader-pdf는 두 가지 형식으로 출력합니다:

### Markdown (테이블 있는 PDF)
```markdown
|품목명|수량|단가|금액|
|---|---|---|---|
|삼각김밥|1|1,500|1,500|
|컵라면|2|1,200|2,400|
```

### JSON (구조화된 데이터)
테이블의 행/열, 셀 단위 바운딩 박스, 폰트 정보 등 포함.

## 제한사항

- PDF 파일만 처리 가능 (이미지 파일은 OCR 엔진 사용)
- 이미지만 포함된 PDF (스캔본)는 이미지로 인식되어 텍스트 추출 불가
- Java 21 이상 필수
