# Google Sheets OAuth2 서비스 계정 설정

## 1. Google Cloud 프로젝트 생성

1. [Google Cloud Console](https://console.cloud.google.com/) 접속
2. 새 프로젝트 생성 또는 기존 프로젝트 선택

## 2. API 활성화

Google Cloud Console에서 다음 API를 활성화:
- Google Sheets API
- Google Drive API

## 3. 서비스 계정 생성

1. IAM & Admin → Service Accounts
2. "Create Service Account" 클릭
3. 이름 입력 (예: `receipt-ocr-sheets`)
4. 역할: 없음 (시트 공유로 권한 관리)
5. 키 생성: JSON 형식으로 다운로드

## 4. 서비스 계정 키 저장

다운로드한 JSON 파일을 안전한 위치에 저장:
```
~/.config/receipt-ocr-sheets/service_account.json
```

**주의: 이 파일을 Git에 커밋하지 마세요!**

## 5. 스프레드시트 권한 설정

서비스 계정 이메일 주소(JSON의 `client_email`)를 스프레드시트에 편집자로 공유:
- 예: `receipt-ocr-sheets@project-id.iam.gserviceaccount.com`

## 6. Python 패키지 설치

```bash
pip install gspread google-auth
```

## 7. 사용 예시

```bash
python scripts/export_gsheet.py receipts.json \
  --credentials ~/.config/receipt-ocr-sheets/service_account.json \
  --spreadsheet "영수증 정리"
```
